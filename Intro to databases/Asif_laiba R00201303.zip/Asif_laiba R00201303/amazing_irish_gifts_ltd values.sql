Insert into MERCHANTS
Values (1,'Asif','Hamza','Pakistan'),
(2,'Young','Alex','Ireland'),
(3,'Osullivan','Peter','UK'),
(4,'Ali','Muhammed','Oman'),
(5,'','Jhon','China'),
(6,'Ali','Laiba','India'),
(7,'OSullivan','Saorise','America'),
(8,'Dowling','Colin','Italy'),
(9,'','Joe','Iran'),
(10,'Fitzgerald','Jade','China');

Insert into CUSTOMER_DETAILS
value (11,'Fitzgerald','Alex','M','2001-09-26','(631)337-9173','28 Main St.','Cork','T12 T9C2'),
(12,'Ali','Sheheryar','M','1996-10-27',' (920)326-2514','55b Defence View','karachi','75D00'),
(13,'Wilton','Harris','M','1990-02-12','(775)336-1311','4277 Little Acres Lane','Glasgow','F61704'),
(14,'Fitzgerald','Becca','F','1997-03-28','(469)338-8872','3891 Shinn Street','New York','10019'),
(15,'Dowling','Wilson','M','2004-05-18','(203)440-0833','2 Stephen st','Dublin','A65 T4T7'),
(16,'Hilton','Saorise','F','1990-11-18','(831)772-5098','3634 Meadow Drive','Glasgow','P59230'),
(17,'Giovanni','Antonio','M','2002-12-02','(772)413-0110','2007 Simpson Street','Milan','612KP'),
(18,'Antonio','Camila','F','2001-11-09','(321)952-1328','2947 Pretty View Lane','Barcelona','294I'),
(19,'','Isabella','F','1993-06-06','(478)922-8294','1658 Medical Center Drive','Venice','342LO'),
(20,'','Valeria','F','2003-01-21','(831)298-8750','31 Eyre Sq.','Limerick','P4 O4P8');

Insert into PRODUCT
value (21,'Parliament Smart Wallet','1820','89.99',1),
(22,'Peak Design Tech Pouch','1000','65.99',5),
(23,'Metro Wind-Resistant Umbrella','9000','79.00',3),
(24,'Shiatsu Back and Neck Massager','2047','60.89',6),
(25,'Connected Cube','7037','50.99',4),
(26,'AirTag Tracker','8200','30.00',10),
(27,'Link & Lock Carabiner for Apple AirTags','2041','120.99',9),
(28,'Essentials A19 Smart Lightbulb','1035','15.99',2),
(29,'Bites 2 Pet Camera with Treat Dispenser','4920','249.99',8),
(30,'Apple Watch Series 7','8043','503.89',7);

Insert into PURCHASED_ORDER
value(31,20,'2019-09-11','2 shamrock park','Cork','T10 T8C2','89.99','21'),
(32,13,'2022-04-28','4277 Little Acres Lane','Glasgow','F61704','65.99','22'),
(33,18,'2022-03-08','2947 Pretty View Lane','Barcelona','294I','79.99','23'),
(34,12,'2019-09-20','55b Defence View','karachi','75D00','503.89','30'),
(35,19,'2020-03-20','1658 Medical Center Drive','Venice','342LO','50.99','25'),
(36,11,'2022-01-22','28 Main St.','Cork','T12 T9C2','30.00','26'),
(37,16,'2018-11-18','3634 Meadow Drive','Glasgow','P59230','120.99','27'),
(38,14,'2018-03-31','3891 Shinn Street','New York','10019','15.99','28'),
(39,17,'2019-11-20','2007 Simpson Street','Milan','612KP','249.99','29'),
(40,15,'2020-07-31','2 Stephen st','Dublin','A65 T4T7','60.89','24');
